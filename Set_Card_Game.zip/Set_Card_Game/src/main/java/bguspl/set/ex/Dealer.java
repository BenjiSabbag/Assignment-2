package bguspl.set.ex;

import bguspl.set.Env;

import java.lang.reflect.Array;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.logging.Level;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * This class manages the dealer's threads and data
 */
public class Dealer implements Runnable {

    /**
     * The game environment object.
     */
    private final Env env;

    /**
     * Game entities.
     */
    private final Table table;
    private final Player[] players;

    /**
     * The list of card ids that are left in the dealer's deck.
     */
    private final List<Integer> deck;

    /**
     * True iff game should be terminated due to an external event.
     */
    private volatile boolean terminate;

    /**
     * The time when the dealer needs to reshuffle the deck due to turn timeout.
     */
    private long reshuffleTime = Long.MAX_VALUE;
    
    // Amount of slots full of cards at this moment.
    private int slotsFull = 0;

    // holds the current time
    private long currTime = 0;

    public PriorityQueue<Player> playersWithSets;

    public Dealer(Env env, Table table, Player[] players) {
        this.env = env;
        this.table = table;
        this.players = players;
        deck = IntStream.range(0, env.config.deckSize).boxed().collect(Collectors.toList());
        playersWithSets = new PriorityQueue<Player>();
    }

    /**
     * The dealer thread starts here (main loop for the dealer thread).
     */
    @Override
    public void run() {
        env.logger.log(Level.INFO, "Thread " + Thread.currentThread().getName() + " starting.");
        for(Player player:players){
            Thread playerThread = new Thread(player);
            playerThread.start();
        }
        while (!shouldFinish()) {
            placeCardsOnTable();
            timerLoop();
            updateTimerDisplay(false);
            removeAllCardsFromTable();
        }
        announceWinners();
        env.logger.log(Level.INFO, "Thread " + Thread.currentThread().getName() + " terminated.");
    }

    /**
     * The inner loop of the dealer thread that runs as long as the countdown did not time out.
     */
    private void timerLoop() {
        while (!terminate && System.currentTimeMillis() < reshuffleTime) {
            sleepUntilWokenOrTimeout();
            updateTimerDisplay(false);
            removeCardsFromTable();
            placeCardsOnTable();
        }
    }

    /**
     * Called when the game should be terminated due to an external event.
     */
    public void terminate() {
        // TODO implement
        for (Player player : players){
            player.terminate();
        }
        notifyAll();
    }

    /**
     * Check if the game should be terminated or the game end conditions are met.
     *
     * @return true iff the game should be finished.
     */
    private boolean shouldFinish() {
        return terminate || env.util.findSets(deck, 1).size() == 0;
    }

    /**
     * Checks cards should be removed from the table and removes them.
     */
    private void removeCardsFromTable() {
        // TODO implement
        try {
            Thread.sleep(env.config.tableDelayMillis);
        } catch (InterruptedException ignored) {}

        for (Player plyr : playersWithSets){
            playersWithSets.remove(plyr);
            if (plyr.maybeSet){
                int[] slotArr = plyr.getSlotArray();
                int[] cardArr = plyr.getCardArray();
                    if (env.util.testSet(cardArr)){
                        plyr.point();    // Add a point to the players score
                        plyr.noSet();
                        for (int slot : slotArr){
                            table.removeCard(slot);
                            decreaseSlots();
                            env.ui.removeTokens(slot);
                            for (Player otherplyr : players){
                                if (otherplyr.isInActions(slot)){
                                    otherplyr.removeFromActions(slot);
                                    otherplyr.maybeSet = false;
                                }
                            }
                        }
                        updateTimerDisplay(true);
                        placeCardsOnTable();
                        notifyAll();
                    }
                else{
                    plyr.penalty();
                    plyr.noSet();
                    notifyAll();
                }
            
            }

        }
    }

    /**
     * Check if any cards can be removed from the deck and placed on the table.
     */
    private void placeCardsOnTable() {
        // TODO implement
        try {
            Thread.sleep(env.config.tableDelayMillis);
        } catch (InterruptedException ignored) {}
        Random rand = new Random();
        if (slotsFull <= 11 & !deck.isEmpty()) {
            shuffle();
            while(!deck.isEmpty() & slotsFull <= 11){      // As long as there are cards in the deck or a slot not empty
                int slot = rand.nextInt(env.config.tableSize);
                if(table.slotToCard[slot] == null & !deck.isEmpty()){
                    table.placeCard(deck.remove(0), slot);
                    increaseSlots();
                }
            }
            currTime = System.currentTimeMillis();
            reshuffleTime = currTime + 60000;
            updateTimerDisplay(true);
        }
        
    }

    /**
     * Sleep for a fixed amount of time or until the thread is awakened for some purpose.
     */
    private void sleepUntilWokenOrTimeout() {
        // TODO implement
        // try {
        //     Thread.sleep(1000);;
        // } catch (InterruptedException e) {}
        
    }

    /**
     * Reset and/or update the countdown and the countdown display.
     */
    private void updateTimerDisplay(boolean reset) {
        // TODO implement
        if (reset){
            env.ui.setCountdown(60000, false);
        }
        env.ui.setCountdown(currTime - System.currentTimeMillis() + 60000 , currTime - System.currentTimeMillis() + 60000 <= 10000);
        
    }

    /**
     * Returns all the cards from the table to the deck.
     */
    private void removeAllCardsFromTable() {
        // TODO implement
        try {
            Thread.sleep(env.config.tableDelayMillis);
        } catch (InterruptedException ignored) {}
        for (int slot = 0; slot <= 11; ++slot){
            table.removeCard(slot);
        }
        slotsFull = 0;
        env.ui.removeTokens();
    }

    /**
     * Check who is/are the winner/s and displays them.
     */
    private void announceWinners() {
        // TODO implement
        int[] winners = new int[players.length];
        int winner = 0;
        int index = 0;
        for (int i = 1; i <= players.length; ++i){
            if (players[i].getScore() > players[winner].getScore()){
                winner = i;
            }
            else if (players[i].getScore() == players[winner].getScore()){
                winners[index] = winner;
                winner = i;
                ++index;
            }
        }
        winners[index] = winner;
        env.ui.announceWinner(winners);
    }

    private void shuffle(){
        Collections.shuffle(deck);
    }

    private void increaseSlots(){
        ++slotsFull;
    }

    private void decreaseSlots(){
        --slotsFull;
    }
}
